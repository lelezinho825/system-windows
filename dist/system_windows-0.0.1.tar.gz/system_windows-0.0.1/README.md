# SystemWindows

## What does this library do?

You can manipulate files.

You can create, delete, and move folders.

You can use cmd commands.

## How it was built?

The programming language I used was Python.

It was inspired by basic libraries.

Created in 2 days

## Why was it built?

I wanted to create this library to 

begin my first steps 

as a programmer.

## How to install

```ps
pip install system-windows
```