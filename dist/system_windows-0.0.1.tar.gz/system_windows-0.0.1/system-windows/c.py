from os import *

class sfol:
    @staticmethod
    def cd(folder):
        chdir(folder)
    @staticmethod
    def md(name):
        mkdir(name)
    @staticmethod
    def rd(name):
        rmdir(name)
    @staticmethod
    def rds(name):
        command = f'rmdir /s {name}'
        system(command)
    @staticmethod
    def rdq(name):
        command = f'rmdir /s /q {name}'
        system(command)
    @staticmethod
    def cdd():
        chdir('/')
    @staticmethod
    def cdp():
        chdir('..')

class sfil:
    @staticmethod
    def create(name):
        command = f'type nul > {name}'
        system(command)
    @staticmethod
    def cecho(content, name):
        command = f'echo {content} > {name}'
        system(command)
    @staticmethod
    def copy(name):
        command = f'copy con {name}'
        system(command)
    @staticmethod
    def delete(name):
        command = f'del {name}'
        system(command)
    @staticmethod
    def ren(name, newname):
        command = f'ren {name} {newname}'
        system(command)
    
class ncm:
    @staticmethod
    def infodir():
        system('dir')
    @staticmethod
    def infodirs():
        system('dir /s')
    @staticmethod
    def startf(name):
        command = f'startfile {name}'
        system(command)
    @staticmethod
    def move(name, folder):
        command = f'move "{name}" "{folder}"'
        system(command)
    @staticmethod
    def content(name):
        command = f'type {name}'
        system(command)
    @staticmethod
    def clear():
        system('cls')
    @staticmethod
    def toswitchoff():
        system('shutdown -s -t 0')
    @staticmethod
    def restart():
        system('shutdown -r -t 0')
    @staticmethod
    def help():
        helpers = [
            'SFOL:',
            'sfol.cd = Displays the folder name or changes the current folder.',
            'sfol.md = Create a folder.',
            'sfol.rd = Remove (delete) a folder.',
            'sfol.cdd = Move the path to the disk.',
            'sfol.cdp = Move to the previous folder.',
            'SFIL:',
            'sfil.create = Create a file',
            'sfil.cecho = Creates a file with content inside.',
            'sfil.copy = Copies one or more files to another location.',
            'sfil.delete = Delete one or more files.',
            'sfil.ren = Renames one or more files.',
            'NCM:',
            'ncm.infodir = Displays a list of files and subdirectories within a directory.',
            'ncm.starf = Execute a file.',
            'ncm.move = Move a file or folder.',
            'ncm.content = Displays the contents of one or more text files.',
            'ncm.clear = Clear the screen.',
            'ncm.toswitchoff = Turn off the computer.',
            'ncm.restart = Restart your computer'
        ]

        for line in helpers:
            print(f'{line} \n')
